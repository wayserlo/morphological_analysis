﻿// -------------------------------------------------------------
// main.cpp -- Инициализация, Парсинг, Выдача отчета, Завершение работы.
//

#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>

#include "config.h"
#include "vocabulary.h"

// -------------------------------------------------------------
// Считывание текста из файла в std::string

std::string text_load(std::string fname)
{
    std::ifstream file( fname );
    std::string text;

    if( file.is_open() ){
        std::stringstream ss;
        ss << file.rdbuf();
        text = ss.str();
        file.close();
    }else{
        std::cout << " Unable to open file " << fname << "." << std::endl;
    }
    return text;
}

// -------------------------------------------------------------
// Запись std::string в файл

void text_save(std::string fname, std::string text)
{
    std::ofstream file(fname);

    if( file.is_open() ){
        file << text;
        file.close();
    }
    
}

// -------------------------------------------------------------
// Преобразование std::string в вектор строк

std::vector<std::string> text_to_vector(std::string text)
{
    std::vector<std::string> lines;
    std::string token;
    std::stringstream ss( text );

    while( getline( ss, token, '\n' ) ){
           lines.push_back( token );
    }

    return lines;
}

// -------------------------------------------------------------
// Вывод вектора в консоль

void vector_to_screen(std::vector<std::string> v)
{
    for( auto& s : v ){
         std::cout << s << std::endl;
    }
}

// -------------------------------------------------------------
// Обработка std::string вектором регулярных выражений

std::string text_prepare(std::string text, std::vector<std::string> regs )
{
    const std::regex ref_re( "\"(.*?)\"\\s*--\\s*\"(.*?)\"" );
    std::smatch res;

    for( auto& regexp : regs ) {
         // для каждой строки выделяем регулярку и замену
         // std::cout << regexp << std::endl;

         std::regex_search(regexp, res, ref_re);
         std::cout << res[1].str() << "  --  " << res[2].str() << std::endl;

         std::regex for_find(res[1].str() );

         text = std::regex_replace(text, for_find, res[2].str());
    }
    
    return text;
}

int main()
{
    setlocale(0, "");

    std::string regexp = text_load("regexp.txt");
    std::vector<std::string> regs = text_to_vector(regexp);

    std::string text = text_load("test.txt");

    text = text_prepare( text, regs );
    std::cout << text << std::endl << std::endl;


    //text = "        Test test Тест тест";
    //text = std::regex_replace( text, std::regex ("^\\s*") , "");
    //std::cout << text << std::endl << std::endl;

    //std::vector<std::string> lines = text_to_vector(text);
    //vector_to_screen( lines );

    // vector_to_screen( regs );

    if( text != "" ) {
        // std::cout << text << std::endl << std::endl;
        text_save("results.txt", text);
    }
}





/*
std::string s = "C*C++*Java";
std::regex regex("\\*");

std::vector<std::string> out(
    std::sregex_token_iterator(s.begin(), s.end(), regex, -1),
    std::sregex_token_iterator()
);

for (auto& s : out) {
    std::cout << s << std::endl;
}

return 0;
*/